const express = require("express");
const mongoose = require("mongoose");
const Movie = require("./models/movieModel");
const movieRoutes = require("./routers/movieRouter");
const app = express();
app.use(express.json());
mongoose
  .connect("mongodb://localhost:27017/myapp")
  .then(() => {
    console.log("Database connected");
    app.listen(3000, () => {
      console.log("API is running in PORT:3000");
    });
  })
  .catch((error) => {
    console.log(error);
  });

app.use("/movie", movieRoutes);
