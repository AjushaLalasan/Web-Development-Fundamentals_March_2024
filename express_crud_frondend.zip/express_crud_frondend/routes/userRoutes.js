const express = require("express");
const router = express.Router();
const userController = require("../controllers/userController");

router.get("/student", userController.getAllStudents);
router.get("/student/:id", userController.getStudentById);
router.post("/student", userController.addStudent);
router.put("/student/:id", userController.updateStudent);
router.delete("/student/:id", userController.deleteStudent);

module.exports = router;
