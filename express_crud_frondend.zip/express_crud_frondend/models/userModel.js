const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  name: String,
  course: String,
  roll_no: String,
});

const User = mongoose.model("User", userSchema);

module.exports = User;
