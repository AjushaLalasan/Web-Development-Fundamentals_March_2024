const User = require("../models/userModel");

exports.getAllStudents = async (req, res) => {
  try {
    const students = await User.find();
    res.json(students);
  } catch (error) {
    console.error("Error fetching students:", error);
    res.status(500).send("Error fetching students");
  }
};

exports.getStudentById = async (req, res) => {
  const { id } = req.params;
  try {
    const student = await User.findById(id);
    if (!student) {
      return res.status(404).send("Student not found");
    }
    res.json(student);
  } catch (error) {
    console.error("Error fetching student:", error);
    res.status(500).send("Error fetching student");
  }
};

exports.addStudent = async (req, res) => {
  const { name, course, roll_no } = req.body;
  try {
    const newStudent = new User({ name, course, roll_no });
    await newStudent.save();
    res.send("Student added successfully");
  } catch (error) {
    console.error("Error adding student:", error);
    res.status(500).send("Error adding student");
  }
};

exports.updateStudent = async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  try {
    const updatedStudent = await User.findByIdAndUpdate(
      id,
      { name },
      { new: true }
    );
    if (!updatedStudent) {
      return res.status(404).send("Student not found");
    }
    res.send("Student updated successfully");
  } catch (error) {
    console.error("Error updating student:", error);
    res.status(500).send("Error updating student");
  }
};

exports.deleteStudent = async (req, res) => {
  const { id } = req.params;
  try {
    const deletedStudent = await User.findByIdAndDelete(id);
    if (!deletedStudent) {
      return res.status(404).send("Student not found");
    }
    res.send("Student deleted successfully");
  } catch (error) {
    console.error("Error deleting student:", error);
    res.status(500).send("Error deleting student");
  }
};
