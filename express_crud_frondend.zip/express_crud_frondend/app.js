const express = require("express");
const mongoose = require("mongoose");
const app = express();
const PORT = 3000;
const studentRoutes = require("./routes/userRoutes");

// Connect to MongoDB database
mongoose
  .connect("mongodb://localhost:27017/studentDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error("Error connecting to MongoDB:", err));

// Middleware to parse JSON request body
app.use(express.json());
app.use(express.static("public"));
// Custom middleware to log each request
app.use(function (req, res, next) {
  console.log("Middleware called");
  next();
});

// Routes
app.use(studentRoutes);

// Start the server
app.listen(PORT, function (err) {
  if (err) console.log(err);
  console.log(`Server listening on PORT ${PORT}`);
});
