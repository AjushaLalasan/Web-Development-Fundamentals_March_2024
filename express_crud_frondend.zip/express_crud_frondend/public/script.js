document.addEventListener("DOMContentLoaded", function () {
  const studentList = document.getElementById("student-list");
  const addStudentForm = document.getElementById("add-student-form");

  // Function to fetch and display students
  function fetchStudents() {
    fetch("/student")
      .then((response) => response.json())
      .then((students) => {
        studentList.innerHTML = ""; // Clear existing student list
        students.forEach((student) => {
          const studentDiv = document.createElement("div");
          studentDiv.classList.add("student");
          studentDiv.innerHTML = `
              <p><strong>Name:</strong> ${student.name}</p>
              <p><strong>Course:</strong> ${student.course}</p>
              <p><strong>Roll No:</strong> ${student.roll_no}</p>
              <p><strong>Id:</strong> ${student._id}</p>
              <button class="btn" onclick="updateStudent('${student._id}')">Update</button>
              <button class="btn" onclick="deleteStudent('${student._id}')">Delete</button>
            `;
          studentList.appendChild(studentDiv);
        });
      })
      .catch((error) => console.error("Error fetching students:", error));
  }

  // Fetch and display students when the page loads
  fetchStudents();

  // Function to add a new student
  addStudentForm.addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form submission
    const name = document.getElementById("name").value;
    const course = document.getElementById("course").value;
    const rollNo = document.getElementById("roll_no").value;

    fetch("/student", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, course, roll_no: rollNo }),
    })
      .then((response) => response.text())
      .then((message) => {
        alert(message);
        fetchStudents(); // Refresh the student list after adding a new student
        addStudentForm.reset(); // Clear the form fields
      })
      .catch((error) => console.error("Error adding student:", error));
  });

  // Function to update a student
  window.updateStudent = function (id) {
    const newName = prompt("Enter new name:");
    if (newName !== null) {
      fetch(`/student/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name: newName }),
      })
        .then((response) => response.text())
        .then((message) => {
          alert(message);
          fetchStudents(); // Refresh the student list after updating a student
        })
        .catch((error) => console.error("Error updating student:", error));
    }
  };

  // Function to delete a student
  window.deleteStudent = function (id) {
    if (confirm("Are you sure you want to delete this student?")) {
      fetch(`/student/${id}`, {
        method: "DELETE",
      })
        .then((response) => response.text())
        .then((message) => {
          alert(message);
          fetchStudents(); // Refresh the student list after deleting a student
        })
        .catch((error) => console.error("Error deleting student:", error));
    }
  };
});
