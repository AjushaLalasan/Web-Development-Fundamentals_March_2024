const likeButton = document.getElementById("likeButton");
const likeCount = document.getElementById("likeCount");
let currentLikes = 0;

likeButton.addEventListener("click", () => {
  currentLikes++;
  likeCount.textContent = `${currentLikes} ${
    currentLikes === 1 ? "Like" : "Likes"
  }`;
});
