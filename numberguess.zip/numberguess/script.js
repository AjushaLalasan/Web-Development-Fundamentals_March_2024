let targetNumber = Math.floor(Math.random() * 100) + 1;
let remainingGuesses = 10;

document.getElementById("guessButton").addEventListener("click", checkGuess);

function checkGuess() {
  const guessInput = document.getElementById("guessInput");
  const output = document.getElementById("output");

  if (remainingGuesses > 0) {
    const userGuess = parseInt(guessInput.value);
    if (userGuess === targetNumber) {
      output.textContent = `Congratulations! You guessed the correct number (${targetNumber}) in ${
        10 - remainingGuesses + 1
      } guesses.`;
      output.style.color = "green";
    } else if (userGuess < targetNumber) {
      output.textContent = "Try a higher number.";
      output.style.color = "blue";
    } else {
      output.textContent = "Try a lower number.";
      output.style.color = "red";
    }

    remainingGuesses--;
    if (remainingGuesses === 0 && userGuess !== targetNumber) {
      output.textContent = `Sorry, you've run out of guesses. The correct number was ${targetNumber}.`;
      output.style.color = "red";
      guessInput.disabled = true;
    }
  }
}
